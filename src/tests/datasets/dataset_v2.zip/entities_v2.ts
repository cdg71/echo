// paramétrage du sondage
export interface Survey {
  id: string;
  name: string;
  hash: string; // hased securityCode
  settingsJson: string; // JSON Schema = SurveySettings
}

export interface settingsJson {
  // Schema used to validate settingsJson in Survey
  description: string;
  context: string;
  created: number; // timestamp
  updated: number; // timestamp
  quiz: string[];
  snapshots: number[];
  positions: string[];
  areas: string[];
}

export interface Snapshots {
  id: string; // PRIMARY KEY
  surveyId: string;
  timestamp: number;
}

// Users
export interface UserId {
  id: string;
  surveyId: string;
  position: string;
  area: string;
}

// Réponses
export interface Response {
  id: string;
  surveyId: string;
  userId: string;
  created: number; // timestamp
  responseJson: string; // JSON Schema = ResponseJson
}

export interface ResponseJson {
  value: string;
  comment: string;
}
[];

export interface Result {
  id: string;
  surveyId: string;
  snapshotId: string;
  detailsJson: string; // JSON schema to be define
  created: number; // timestamp
  completed: number; // timestamp
}
